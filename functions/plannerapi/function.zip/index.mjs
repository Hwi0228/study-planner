import net from 'node:net';
import tls from 'node:tls';
import {
  randomBytes,
  pbkdf2Sync,
  createHmac,
  createHash,
  timingSafeEqual,
  createPublicKey,
  verify as verifySignature,
} from 'node:crypto';

const DATABASE_URL = process.env.PLANNER_DATABASE_URL || process.env.DATABASE_URL;
if (!DATABASE_URL) throw new Error('DATABASE_URL is not available on this branch');

const dbUrl = new URL(DATABASE_URL);
const AUTH_BASE_URL = process.env.NEON_AUTH_BASE_URL;
const AUTH_JWKS_URL = process.env.NEON_AUTH_JWKS_URL;
if (!AUTH_BASE_URL || !AUTH_JWKS_URL) throw new Error('Neon Auth is not available on this branch');
const AUTH_ISSUER = new URL(AUTH_BASE_URL).origin;
let jwksCache = { keys: [], expiresAt: 0 };

const DB = {
  host: dbUrl.hostname,
  port: Number(dbUrl.port || 5432),
  user: decodeURIComponent(dbUrl.username),
  password: decodeURIComponent(dbUrl.password),
  database: decodeURIComponent(dbUrl.pathname.replace(/^\//, '')),
};

const ALLOWED_ORIGINS = new Set([
  'https://study-planner-sc15.onrender.com',
  'https://studygrade.kro.kr',
  'http://localhost:5500',
  'http://127.0.0.1:5500',
]);
const UUID_RE = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
const DATE_RE = /^\d{4}-\d{2}-\d{2}$/;
const TIME_RE = /^(?:[01]\d|2[0-3]):[0-5]\d$/;
const COLOR_RE = /^#[0-9a-f]{6}$/i;
const MAX_BODY_BYTES = 512 * 1024;

function hmac(key, value) {
  return createHmac('sha256', key).update(value).digest();
}

function sha256(value) {
  return createHash('sha256').update(value).digest();
}

function parseError(body) {
  const fields = {};
  let offset = 0;
  while (offset < body.length && body[offset] !== 0) {
    const code = String.fromCharCode(body[offset++]);
    const end = body.indexOf(0, offset);
    if (end < 0) break;
    fields[code] = body.toString('utf8', offset, end);
    offset = end + 1;
  }
  return new Error(fields.M || fields.S || 'PostgreSQL query failed');
}

async function openTlsSocket() {
  const raw = net.createConnection({ host: DB.host, port: DB.port });
  raw.setTimeout(15000);
  await new Promise((resolve, reject) => {
    raw.once('connect', resolve);
    raw.once('error', reject);
    raw.once('timeout', () => reject(new Error('Database TCP connection timed out')));
  });

  const sslRequest = Buffer.alloc(8);
  sslRequest.writeInt32BE(8, 0);
  sslRequest.writeInt32BE(80877103, 4);
  raw.write(sslRequest);
  const sslResponse = await new Promise((resolve, reject) => {
    const onData = (chunk) => {
      raw.off('error', onError);
      resolve(chunk);
    };
    const onError = (error) => {
      raw.off('data', onData);
      reject(error);
    };
    raw.once('data', onData);
    raw.once('error', onError);
  });
  if (!sslResponse.length || sslResponse[0] !== 0x53) {
    raw.destroy();
    throw new Error('Neon endpoint did not accept TLS');
  }

  const socket = tls.connect({ socket: raw, servername: DB.host, rejectUnauthorized: true });
  socket.setTimeout(20000);
  await new Promise((resolve, reject) => {
    socket.once('secureConnect', resolve);
    socket.once('error', reject);
    socket.once('timeout', () => reject(new Error('Database TLS handshake timed out')));
  });
  return socket;
}

function makeMessage(type, payload) {
  const header = Buffer.alloc(5);
  header[0] = type.charCodeAt(0);
  header.writeInt32BE(payload.length + 4, 1);
  return Buffer.concat([header, payload]);
}

async function connectPostgres() {
  const socket = await openTlsSocket();
  const iterator = socket[Symbol.asyncIterator]();
  let pending = Buffer.alloc(0);

  async function readExact(length) {
    while (pending.length < length) {
      const next = await iterator.next();
      if (next.done) throw new Error('Database connection closed unexpectedly');
      pending = Buffer.concat([pending, Buffer.from(next.value)]);
    }
    const result = pending.subarray(0, length);
    pending = pending.subarray(length);
    return result;
  }

  async function readMessage() {
    const type = (await readExact(1)).toString('utf8');
    const length = (await readExact(4)).readInt32BE(0);
    if (length < 4 || length > 16 * 1024 * 1024) throw new Error('Invalid PostgreSQL message length');
    return { type, body: await readExact(length - 4) };
  }

  function send(type, payload) {
    if (!socket.write(makeMessage(type, payload))) {
      // Messages are small; the TLS socket buffers them when back-pressured.
    }
  }

  const startupFields = Buffer.from(
    `user\0${DB.user}\0database\0${DB.database}\0application_name\0studygrade-api\0client_encoding\0UTF8\0\0`,
    'utf8',
  );
  const startup = Buffer.alloc(8 + startupFields.length);
  startup.writeInt32BE(startup.length, 0);
  startup.writeInt32BE(196608, 4);
  startupFields.copy(startup, 8);
  socket.write(startup);

  let serverFirst = '';
  let clientFirstBare = '';
  let expectedServerSignature = null;
  let authenticated = false;

  while (!authenticated) {
    const message = await readMessage();
    if (message.type === 'E') throw parseError(message.body);
    if (message.type !== 'R') continue;
    const authType = message.body.readInt32BE(0);

    if (authType === 10) {
      const mechanisms = message.body.subarray(4).toString('utf8').split('\0').filter(Boolean);
      if (!mechanisms.includes('SCRAM-SHA-256')) throw new Error('Neon did not offer SCRAM-SHA-256');
      const nonce = randomBytes(18).toString('base64');
      const saslUser = DB.user.replace(/=/g, '=3D').replace(/,/g, '=2C');
      clientFirstBare = `n=${saslUser},r=${nonce}`;
      const clientFirst = `n,,${clientFirstBare}`;
      const firstBytes = Buffer.from(clientFirst, 'utf8');
      const mechanism = Buffer.from('SCRAM-SHA-256\0', 'utf8');
      const initial = Buffer.alloc(mechanism.length + 4 + firstBytes.length);
      mechanism.copy(initial, 0);
      initial.writeInt32BE(firstBytes.length, mechanism.length);
      firstBytes.copy(initial, mechanism.length + 4);
      send('p', initial);
    } else if (authType === 11) {
      serverFirst = message.body.subarray(4).toString('utf8');
      const attrs = Object.fromEntries(serverFirst.split(',').map((part) => [part[0], part.slice(2)]));
      if (!attrs.r || !attrs.s || !attrs.i) throw new Error('Invalid SCRAM server challenge');
      const nonce = clientFirstBare.match(/,r=([^,]+)/)?.[1];
      if (!nonce || !attrs.r.startsWith(nonce)) throw new Error('Invalid SCRAM server nonce');
      const iterations = Number(attrs.i);
      if (!Number.isInteger(iterations) || iterations < 1 || iterations > 1000000) throw new Error('Invalid SCRAM iteration count');
      const salt = Buffer.from(attrs.s, 'base64');
      const saltedPassword = pbkdf2Sync(DB.password, salt, iterations, 32, 'sha256');
      const clientKey = hmac(saltedPassword, 'Client Key');
      const storedKey = sha256(clientKey);
      const serverKey = hmac(saltedPassword, 'Server Key');
      const finalWithoutProof = `c=biws,r=${attrs.r}`;
      const authMessage = `${clientFirstBare},${serverFirst},${finalWithoutProof}`;
      const clientSignature = hmac(storedKey, authMessage);
      const proof = Buffer.alloc(clientKey.length);
      for (let i = 0; i < clientKey.length; i++) proof[i] = clientKey[i] ^ clientSignature[i];
      expectedServerSignature = hmac(serverKey, authMessage);
      const finalMessage = `${finalWithoutProof},p=${proof.toString('base64')}`;
      send('p', Buffer.from(finalMessage, 'utf8'));
    } else if (authType === 12) {
      const finalText = message.body.subarray(4).toString('utf8');
      const signature = finalText.split(',').find((part) => part.startsWith('v='))?.slice(2);
      if (!signature || !expectedServerSignature) throw new Error('Invalid SCRAM server signature');
      const actual = Buffer.from(signature, 'base64');
      if (actual.length !== expectedServerSignature.length || !timingSafeEqual(actual, expectedServerSignature)) {
        throw new Error('PostgreSQL SCRAM server signature did not match');
      }
    } else if (authType === 0) {
      // Authentication is complete; wait for ReadyForQuery below.
      let ready = false;
      while (!ready) {
        const followup = await readMessage();
        if (followup.type === 'E') throw parseError(followup.body);
        if (followup.type === 'Z') ready = true;
      }
      authenticated = true;
    } else {
      throw new Error(`Unsupported PostgreSQL authentication method: ${authType}`);
    }
  }

  async function query(sql) {
    send('Q', Buffer.from(`${sql}\0`, 'utf8'));
    let columns = [];
    const rows = [];
    let command = '';
    while (true) {
      const message = await readMessage();
      if (message.type === 'E') throw parseError(message.body);
      if (message.type === 'T') {
        let offset = 0;
        const count = message.body.readInt16BE(offset); offset += 2;
        columns = [];
        for (let i = 0; i < count; i++) {
          const end = message.body.indexOf(0, offset);
          const name = message.body.toString('utf8', offset, end);
          offset = end + 1 + 18;
          columns.push(name);
        }
      } else if (message.type === 'D') {
        let offset = 0;
        const count = message.body.readInt16BE(offset); offset += 2;
        const row = {};
        for (let i = 0; i < count; i++) {
          const length = message.body.readInt32BE(offset); offset += 4;
          const value = length === -1 ? null : message.body.toString('utf8', offset, offset + length);
          if (length !== -1) offset += length;
          row[columns[i] || String(i)] = value;
        }
        rows.push(row);
      } else if (message.type === 'C') {
        command = message.body.toString('utf8').replace(/\0$/, '');
      } else if (message.type === 'Z') {
        return { rows, command };
      }
    }
  }

  return {
    query,
    close: () => socket.end(),
  };
}

async function query(sql) {
  const client = await connectPostgres();
  try {
    return await client.query(sql);
  } finally {
    client.close();
  }
}

async function getJwks() {
  if (jwksCache.expiresAt > Date.now() && jwksCache.keys.length) return jwksCache.keys;
  const response = await fetch(AUTH_JWKS_URL, { headers: { accept: 'application/json' } });
  if (!response.ok) throw new Error(`JWKS request failed: ${response.status}`);
  const payload = await response.json();
  if (!Array.isArray(payload.keys) || !payload.keys.length) throw new Error('Managed Auth JWKS is empty');
  jwksCache = { keys: payload.keys, expiresAt: Date.now() + 5 * 60 * 1000 };
  return jwksCache.keys;
}

async function authenticateRequest(request) {
  const authorization = request.headers.get('authorization') || '';
  const match = authorization.match(/^Bearer\s+(.+)$/i);
  if (!match) return null;
  try {
    const token = match[1];
    const parts = token.split('.');
    if (parts.length !== 3) return null;
    const header = JSON.parse(Buffer.from(parts[0], 'base64url').toString('utf8'));
    const claims = JSON.parse(Buffer.from(parts[1], 'base64url').toString('utf8'));
    if (header.alg !== 'EdDSA' || typeof header.kid !== 'string') return null;
    if (claims.iss !== AUTH_ISSUER) return null;
    const audiences = Array.isArray(claims.aud) ? claims.aud : [claims.aud];
    if (!audiences.includes(AUTH_ISSUER)) return null;
    const now = Math.floor(Date.now() / 1000);
    if (!Number.isFinite(claims.exp) || claims.exp <= now) return null;
    if (Number.isFinite(claims.nbf) && claims.nbf > now + 30) return null;
    if (typeof claims.sub !== 'string' || !UUID_RE.test(claims.sub)) return null;
    const keys = await getJwks();
    const jwk = keys.find((key) => key.kid === header.kid && key.kty === 'OKP' && key.crv === 'Ed25519');
    if (!jwk) return null;
    const publicKey = createPublicKey({ key: jwk, format: 'jwk' });
    const signed = Buffer.from(`${parts[0]}.${parts[1]}`, 'utf8');
    const signature = Buffer.from(parts[2], 'base64url');
    if (!verifySignature(null, signed, publicKey, signature)) return null;
    return claims.sub;
  } catch (error) {
    console.warn('JWT verification rejected:', error?.message || error);
    return null;
  }
}

function jsonResponse(data, status = 200, corsHeaders = {}) {
  return new Response(JSON.stringify(data), {
    status,
    headers: { 'content-type': 'application/json; charset=utf-8', ...corsHeaders },
  });
}

function mondayOf(dateString) {
  const date = new Date(`${dateString}T00:00:00.000Z`);
  if (!Number.isFinite(date.getTime()) || date.toISOString().slice(0, 10) !== dateString) return null;
  const day = date.getUTCDay();
  return day === 0 ? new Date(date.getTime() - 6 * 86400000).toISOString().slice(0, 10)
    : new Date(date.getTime() - (day - 1) * 86400000).toISOString().slice(0, 10);
}

function validateWeeks(value) {
  if (!value || typeof value !== 'object' || Array.isArray(value)) return false;
  const keys = Object.keys(value);
  if (keys.length > 156) return false;
  for (const week of keys) {
    if (!DATE_RE.test(week) || mondayOf(week) !== week || !Array.isArray(value[week]) || value[week].length > 500) return false;
    for (const event of value[week]) {
      if (!event || typeof event !== 'object' || Array.isArray(event)) return false;
      if (typeof event.id !== 'string' || event.id.length < 1 || event.id.length > 100) return false;
      if (typeof event.title !== 'string' || event.title.trim().length < 1 || event.title.length > 60) return false;
      if (typeof event.date !== 'string' || !DATE_RE.test(event.date) || mondayOf(event.date) !== week) return false;
      if (typeof event.start !== 'string' || !TIME_RE.test(event.start)) return false;
      if (typeof event.end !== 'string' || !TIME_RE.test(event.end)) return false;
      const start = Number(event.start.slice(0, 2)) * 60 + Number(event.start.slice(3));
      const end = Number(event.end.slice(0, 2)) * 60 + Number(event.end.slice(3));
      if (start < 360 || end > 1440 || end <= start) return false;
      if (typeof event.subject !== 'string' || event.subject.length > 30) return false;
      if (event.color !== undefined && !COLOR_RE.test(event.color)) return false;
      if (event.note !== undefined && (typeof event.note !== 'string' || event.note.length > 180)) return false;
      if (event.recurrence !== undefined) {
        const recurrence = event.recurrence;
        if (!recurrence || typeof recurrence !== 'object' || Array.isArray(recurrence)) return false;
        if (!['daily', 'weekly', 'weekdays', 'monthly'].includes(recurrence.frequency)) return false;
        if (!Number.isInteger(recurrence.interval) || recurrence.interval < 1 || recurrence.interval > 12) return false;
        if (recurrence.until !== null && recurrence.until !== undefined) {
          if (typeof recurrence.until !== 'string' || !DATE_RE.test(recurrence.until) || recurrence.until < event.date) return false;
        }
        if (recurrence.weekdays !== undefined && (!Array.isArray(recurrence.weekdays) || recurrence.weekdays.length > 7 || recurrence.weekdays.some(day => !Number.isInteger(day) || day < 0 || day > 6))) return false;
        if (recurrence.exceptions !== undefined && (!Array.isArray(recurrence.exceptions) || recurrence.exceptions.length > 1000 || recurrence.exceptions.some(date => typeof date !== 'string' || !DATE_RE.test(date)))) return false;
      }
      if (event.overrideOf !== undefined && (typeof event.overrideOf !== 'string' || event.overrideOf.length > 100)) return false;
    }
  }
  return true;
}

function validateShareSnapshot(weekStart, events) {
  if (typeof weekStart !== 'string' || !DATE_RE.test(weekStart) || mondayOf(weekStart) !== weekStart) return false;
  return validateWeeks({ [weekStart]: events });
}

async function readBody(request) {
  const reader = request.body?.getReader();
  if (!reader) return '';
  const chunks = [];
  let total = 0;
  while (true) {
    const { done, value } = await reader.read();
    if (done) break;
    total += value.byteLength;
    if (total > MAX_BODY_BYTES) throw new Error('BODY_TOO_LARGE');
    chunks.push(value);
  }
  const joined = new Uint8Array(total);
  let offset = 0;
  for (const chunk of chunks) { joined.set(chunk, offset); offset += chunk.byteLength; }
  return new TextDecoder().decode(joined);
}

export default {
  async fetch(request) {
    const origin = request.headers.get('origin');
    const cors = {
      'access-control-allow-methods': 'GET, PUT, POST, DELETE, OPTIONS',
      'access-control-allow-headers': 'authorization, content-type, x-legacy-planner-id',
      'access-control-max-age': '86400',
      'vary': 'Origin',
    };
    if (origin && !ALLOWED_ORIGINS.has(origin)) return jsonResponse({ error: 'origin_not_allowed' }, 403);
    if (origin) cors['access-control-allow-origin'] = origin;
    if (request.method === 'OPTIONS') return new Response(null, { status: 204, headers: cors });

    const url = new URL(request.url);
    if (url.pathname === '/health' && request.method === 'GET') {
      try {
        await query('SELECT 1 AS ok');
        await getJwks();
        return jsonResponse({ ok: true, service: 'studygrade-api', database: 'connected', auth: 'ready' }, 200, cors);
      } catch (error) {
        console.error('Health check failed:', error?.message || error);
        return jsonResponse({ ok: false, database: 'unavailable' }, 503, cors);
      }
    }

    const publicShareMatch = url.pathname.match(/^\/api\/shares\/([0-9a-f]{64})$/i);
    if (publicShareMatch && request.method === 'GET') {
      try {
        const tokenHash = sha256(publicShareMatch[1].toLowerCase()).toString('hex');
        const result = await query(
          `SELECT week_start::text AS week_start, events::text AS events, expires_at::text AS expires_at FROM public.planner_shares WHERE token_hash = '${tokenHash}' AND revoked_at IS NULL AND (expires_at IS NULL OR expires_at > now()) LIMIT 1`,
        );
        if (!result.rows.length) return jsonResponse({ error: 'share_not_found' }, 404, cors);
        return jsonResponse({ exists: true, version: 1, weekStart: result.rows[0].week_start, events: JSON.parse(result.rows[0].events), expiresAt: result.rows[0].expires_at }, 200, cors);
      } catch (error) {
        console.error('Public share read failed:', error?.message || error);
        return jsonResponse({ error: 'share_unavailable' }, 503, cors);
      }
    }

    const userId = await authenticateRequest(request);
    if (!userId) return jsonResponse({ error: 'unauthorized' }, 401, cors);

    if (url.pathname === '/api/shares' && request.method === 'GET') {
      try {
        const result = await query(
          `SELECT id::text AS id, week_start::text AS week_start, created_at::text AS created_at, expires_at::text AS expires_at, revoked_at::text AS revoked_at, (revoked_at IS NULL AND (expires_at IS NULL OR expires_at > now()))::text AS active FROM public.planner_shares WHERE owner_id = '${userId}'::uuid ORDER BY created_at DESC LIMIT 50`,
        );
        return jsonResponse({ shares: result.rows.map(row => ({ id: row.id, weekStart: row.week_start, createdAt: row.created_at, expiresAt: row.expires_at, revokedAt: row.revoked_at, active: row.active === 'true' })) }, 200, cors);
      } catch (error) {
        console.error('Share list failed:', error?.message || error);
        return jsonResponse({ error: 'share_unavailable' }, 503, cors);
      }
    }

    if (url.pathname === '/api/shares' && request.method === 'POST') {
      let payload;
      try {
        const raw = await readBody(request);
        payload = JSON.parse(raw || '{}');
      } catch (error) {
        return jsonResponse({ error: error.message === 'BODY_TOO_LARGE' ? 'payload_too_large' : 'invalid_json' }, error.message === 'BODY_TOO_LARGE' ? 413 : 400, cors);
      }
      const expiresInDays = payload.expiresInDays;
      if (!validateShareSnapshot(payload.weekStart, payload.events) || ![7, 30, 90, 0].includes(expiresInDays)) {
        return jsonResponse({ error: 'invalid_share_data' }, 400, cors);
      }
      try {
        const token = randomBytes(32).toString('hex');
        const tokenHash = sha256(token).toString('hex');
        const serialized = JSON.stringify(payload.events).replace(/'/g, "''");
        const expiry = expiresInDays === 0 ? 'NULL' : `now() + interval '${expiresInDays} days'`;
        const result = await query(
          `INSERT INTO public.planner_shares (owner_id, token_hash, week_start, events, expires_at) VALUES ('${userId}'::uuid, '${tokenHash}', '${payload.weekStart}'::date, '${serialized}'::jsonb, ${expiry}) RETURNING id::text AS id, expires_at::text AS expires_at`,
        );
        return jsonResponse({ ok: true, id: result.rows[0].id, token, expiresAt: result.rows[0].expires_at }, 201, cors);
      } catch (error) {
        console.error('Share creation failed:', error?.message || error);
        return jsonResponse({ error: 'share_unavailable' }, 503, cors);
      }
    }

    const revokeShareMatch = url.pathname.match(/^\/api\/shares\/([0-9a-f-]{36})$/i);
    if (revokeShareMatch && request.method === 'DELETE') {
      if (!UUID_RE.test(revokeShareMatch[1])) return jsonResponse({ error: 'invalid_share_id' }, 400, cors);
      try {
        const result = await query(
          `UPDATE public.planner_shares SET revoked_at = COALESCE(revoked_at, now()) WHERE id = '${revokeShareMatch[1]}'::uuid AND owner_id = '${userId}'::uuid RETURNING id::text AS id`,
        );
        if (!result.rows.length) return jsonResponse({ error: 'share_not_found' }, 404, cors);
        return jsonResponse({ ok: true }, 200, cors);
      } catch (error) {
        console.error('Share revocation failed:', error?.message || error);
        return jsonResponse({ error: 'share_unavailable' }, 503, cors);
      }
    }

    if (url.pathname !== '/api/planner' || !['GET', 'PUT'].includes(request.method)) {
      return jsonResponse({ error: 'not_found' }, 404, cors);
    }
    if (!userId) return jsonResponse({ error: 'unauthorized' }, 401, cors);

    if (request.method === 'GET') {
      try {
        let result = await query(
          `SELECT weeks::text AS weeks, updated_at::text AS updated_at FROM public.planner_accounts WHERE user_id = '${userId}'::uuid LIMIT 1`,
        );
        // One-time import of the previous anonymous browser profile, only if this account has no row yet.
        const legacyPlannerId = request.headers.get('x-legacy-planner-id') || '';
        if (!result.rows.length && UUID_RE.test(legacyPlannerId)) {
          const legacy = await query(
            `SELECT weeks::text AS weeks FROM public.planner_data WHERE owner_id = '${legacyPlannerId}'::uuid LIMIT 1`,
          );
          if (legacy.rows.length) {
            const legacyWeeks = JSON.parse(legacy.rows[0].weeks);
            if (validateWeeks(legacyWeeks)) {
              const serialized = JSON.stringify(legacyWeeks).replace(/'/g, "''");
              result = await query(
                `INSERT INTO public.planner_accounts (user_id, weeks, updated_at) VALUES ('${userId}'::uuid, '${serialized}'::jsonb, now()) RETURNING weeks::text AS weeks, updated_at::text AS updated_at`,
              );
            }
          }
        }
        if (!result.rows.length) return jsonResponse({ exists: false, weeks: {} }, 200, cors);
        return jsonResponse({ exists: true, weeks: JSON.parse(result.rows[0].weeks), updatedAt: result.rows[0].updated_at }, 200, cors);
      } catch (error) {
        console.error('Planner account read failed:', error?.message || error);
        return jsonResponse({ error: 'database_unavailable' }, 503, cors);
      }
    }

    let payload;
    try {
      const raw = await readBody(request);
      payload = JSON.parse(raw || '{}');
    } catch (error) {
      return jsonResponse({ error: error.message === 'BODY_TOO_LARGE' ? 'payload_too_large' : 'invalid_json' }, error.message === 'BODY_TOO_LARGE' ? 413 : 400, cors);
    }
    if (!validateWeeks(payload.weeks)) return jsonResponse({ error: 'invalid_planner_data' }, 400, cors);

    try {
      const serialized = JSON.stringify(payload.weeks).replace(/'/g, "''");
      const result = await query(
        `INSERT INTO public.planner_accounts (user_id, weeks, updated_at) VALUES ('${userId}'::uuid, '${serialized}'::jsonb, now()) ON CONFLICT (user_id) DO UPDATE SET weeks = EXCLUDED.weeks, updated_at = now() RETURNING updated_at::text AS updated_at`,
      );
      return jsonResponse({ ok: true, updatedAt: result.rows[0]?.updated_at || null }, 200, cors);
    } catch (error) {
      console.error('Planner account write failed:', error?.message || error);
      return jsonResponse({ error: 'database_unavailable' }, 503, cors);
    }
  },
};
